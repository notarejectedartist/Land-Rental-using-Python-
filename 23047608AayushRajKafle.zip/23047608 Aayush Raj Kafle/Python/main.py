import read
import write
import operations

def main_menu(lands):
    try:
        print("="*33 + "Welcome to Techno Nepal Land Rental System" + "="*33)
        print("+"*(42+20+29))
        print("1. Rent")
        print("2. Return")
        print("3. Exit")
        print("4. Show Lands")
        print("+"*(42+20+29))
        choice = int(input("Choose from the following options: "))
        return choice, lands
    except ValueError:
        print("Invalid input. Please enter a valid option (1 / 2 / 3 / 4).")
        return main_menu(lands)

def rent_more():
    while True:
        response = input("Do you want to rent more land (yes/no): ").lower()
        if response == 'yes':
            return 'yes'
        elif response == 'no':
            return 'no'
        else:
            print("Invalid input. Please enter 'yes' or 'no'.")

def check_availability(lands, kitta_number):
    for land in lands:
        if land['kitta_number'] == kitta_number:
            if land['status'] == "Available":
                while True:
                    name = input("Enter your Name: ")
                    if not name.replace(" ", "").isalpha():
                        print("Please enter a valid name.")
                    else:
                        break  # Break the loop if name is valid
                while True:
                    phone_number = input("Enter your Phone Number: ")
                    if not phone_number.isdigit() or len(phone_number) != 10:
                        print("Please enter a valid phone number.")
                    else:
                        break  # Break the loop if phone number is valid
                while True:
                    address = input("Enter Your Address: ")
                    if not address:
                        print("Please enter your address.")
                    else:
                        break  # Break the loop if address is provided
                while True:
                    lease_period = input("Enter lease period (in months): ")
                    if not lease_period.isdigit():
                        print("Please enter a valid number.")
                    else:
                        break  # Break the loop if lease period is valid
                renter_info = {'name': name, 'phone_number': phone_number, 'address': address, 'lease_period': lease_period}
                return True, renter_info, land  # Return tuple (True, renter_info, land) if all inputs are valid
            else:
                print("This land is already rented. Please choose another.")
                return False, None, None  # Return tuple (False, None, None) if land is not available
    print("Land with kitta number {} does not exist. Please choose again from the table.".format(kitta_number))
    return False, None, None  # Return tuple (False, None, None) if land with kitta number does not exist

def check_unavailability(lands, kitta_number):
    for land in lands:
        if land['kitta_number'] == kitta_number:
            if land['status'] == "Unavailable":
                while True:
                    name = input("Enter your Name: ")
                    if not name.replace(" ", "").isalpha():
                        print("Please enter a valid name.")
                    else:
                        break  # Break the loop if name is valid
                while True:
                    phone_number = input("Enter your Phone Number: ")
                    if not phone_number.isdigit() or len(phone_number) != 10:
                        print("Please enter a valid phone number.")
                    else:
                        break  # Break the loop if phone number is valid
                while True:
                    address = input("Enter Your Address: ")
                    if not address:
                        print("Please enter your address.")
                    else:
                        break  # Break the loop if address is provided
                while True:
                    leased_period = input("Enter leased period (in months): ")
                    if not leased_period.isdigit():
                        print("Please enter a valid number.")
                        continue  # Continue the loop if lease period is not valid
                    else:
                        break  # Break the loop if lease period is valid
                while True:
                    actual_lease_period = input("Enter actual leased period (in months): ")
                    if not actual_lease_period.isdigit():
                        print("Please enter a valid number.")
                    else:
                        break  # Break the loop if actual lease period is valid
                ex_renter_info = {'name': name, 'phone_number': phone_number, 'address': address, 'leased_period': leased_period, 'actual_lease_period': actual_lease_period}
                return True, ex_renter_info, land  # Return tuple (True, ex_renter_info, land) if all inputs are valid
            else:
                print("This land has not rented. Please choose the land that you rented.")
                return False, None, None  # Return tuple (False, None, None) if land is not unavailable
    print("Land with kitta number {} does not exist. Please choose again from the table.".format(kitta_number))
    return False, None, None  # Return tuple (False, None, None) if land with kitta number does not exist

# Main menu
lands = read.read_lands()  # Read land data from file

while True:
    try:
        choice, _ = main_menu(lands)
        if choice == 1:
            print("You have chosen to Rent a land.")
            filename = None  # Initialize filename
            while True:
                read.display_lands(lands)
                try:
                    kitta_number = int(input("Enter the kitta number of the land you want to rent: "))
                except ValueError:
                    print("Invalid input. Please enter a valid kitta number.")
                    continue
                success, renter_info, land = check_availability(lands, kitta_number)
                if success:
                    response = rent_more()
                    if response == 'yes':
                        filename = input("Enter the filename to append the invoice: ")
                    write.rent_invoice(renter_info, land, response, filename)
                    if response == 'yes':
                        continue  # Go back to showing the table
                    else:
                        break  # Go back to main menu

        elif choice == 2:
            # Option 2: Return a previously rented land
            print("You have chosen to Return the previously rented land.")
            filename = None  # Initialize filename
            while True:
                read.display_lands(lands)
                try:
                    kitta_number = int(input("Enter the kitta number of the land you want to return: "))
                except ValueError:
                    print("Invalid input. Please enter a valid kitta number.")
                    continue
                success, ex_renter_info, land = check_unavailability(lands, kitta_number)
                if success:
                    response = input("Enter the filename to append the invoice (Press Enter for default): ")
                    if response:
                        filename = response
                    write.return_invoice(ex_renter_info, land, filename)
                    break  # Go back to main menu

        elif choice == 3:
            print("Thank you for Choosing Techno Nepal")
            break
        elif choice == 4:
            read.display_lands(lands)
            
        else:
            print("Please choose a valid option")

    except ValueError:
        print("Invalid input. Please enter a valid option.")
