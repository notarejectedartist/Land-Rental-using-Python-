def read_lands():
    """Reads land data from 'table.txt' and returns a list of dictionaries."""
    lands = []
    try:
        with open('table.txt', 'r') as file:
            for line in file:
                # Split line into data elements (assuming whitespace separated)
                data = line.split('|') 

                if len(data) == 6:                      # Ensure 6 columns
                    kitta_number = int(data[0].split()[0]) # Kitta no
                    city = data[1].split()[0]              # City name
                    direction = data[2].split()[0]         # Direction
                    anna = int(data[3].split()[0])         # Land area (anna) 
                    price = int(data[4].split()[0])        # Price 
                    status = data[5].split()[0]            # Status

                    # Create a dictionary for each land entry
                    land_data = {
                        'kitta_number': kitta_number,
                        'city': city,
                        'direction': direction,
                        'anna': anna,
                        'price': price,
                        'status': status
                    }
                    lands.append(land_data)
    except FileNotFoundError:
        print("Error: Data file not found.")
    return lands

def display_lands(lands):
    """Displays the list of lands in a tabular format."""
    if not lands:
        print("No land data to display.")
        return
    headers = lands[0].keys()
    print("\t" + "\t".join(headers) + "\t")
    print("\t" + "\t".join(["-" * len(header) for header in headers]) + "\t")
    for land in lands:
        values = [str(land[header]) for header in headers]
        print("\t" + "\t".join(values) + "\t")

# Read land data from file
lands = read_lands()

# Display land data in tabular format
#display_lands(lands)
