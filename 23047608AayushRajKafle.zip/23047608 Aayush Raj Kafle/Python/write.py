import datetime
import operations

def rent_invoice(renter_info, land, response, filename=None):
    invoice_number = operations.generate_code()
    invoice_text = "="*32 + "Rent Invoice" + "="*32 + "\n"
    invoice_text += "\t" * 4 + "Invoice Number: " + str(invoice_number) + "\n"
    invoice_text += "\t" * 4 + "Customer Name: " + renter_info['name'] + "\n"
    invoice_text += "\t" * 4 + "Phone Number: " + renter_info['phone_number'] + "\n"
    invoice_text += "\t" * 4 + "Address: " + renter_info['address'] + "\n"
    invoice_text += "\t" * 4 + "Leased Period (in months): " + str(renter_info['lease_period']) + "\n"
    invoice_text += "\t" * 4 + "Kitta Number Leased: " + str(land['kitta_number']) + "\n"
    invoice_text += "\t" * 4 + "Price per Aana: " + str(land['price']) + "\n"
    total_cost = operations.rent_total_cost(land['price'], land['anna'], int(renter_info['lease_period']))
    invoice_text += "\t" * 4 + "Total Cost: Rs " + str(total_cost) + "\n"

    print(invoice_text)
    
    # Update table in terminal
    land['status'] = "Unavailable"
    update_file_after_rent(land['kitta_number'], "Unavailable")
    
    if response == 'yes':
        if filename:
            with open(filename, 'a') as file:
                file.write(invoice_text + "\n\n")
        else:
            print("No filename provided.")
    else:
        if filename:
            with open(filename, 'w') as file:
                file.write(invoice_text)
        else:
            print("No filename provided.")
            
    return response  # Return the response for further processing

def return_invoice(renter_info, land, filename=None):
    invoice_number = operations.generate_code()
    leased_period = int(renter_info['leased_period'])
    actual_lease_period = int(renter_info['actual_lease_period'])
    remaining_months = actual_lease_period - leased_period
    extra_months = leased_period - actual_lease_period
    
    invoice_text = "="*32 + "Return Invoice" + "="*32 + "\n"
    invoice_text += "\t" * 4 + "Invoice Number: " + str(invoice_number) + "\n"
    invoice_text += "\t" * 4 + "Customer Name: " + renter_info['name'] + "\n"
    invoice_text += "\t" * 4 + "Phone Number: " + renter_info['phone_number'] + "\n"
    invoice_text += "\t" * 4 + "Address: " + renter_info['address'] + "\n"
    invoice_text += "\t" * 4 + "Kitta Number Leased: " + str(land['kitta_number']) + "\n"
    invoice_text += "\t" * 4 + "Aana Leased: " + str(land['anna']) + "\n"
    invoice_text += "\t" * 4 + "Price per Aana: " + str(land['price']) + "\n"
    
    if actual_lease_period < leased_period:
        invoice_text += "\t" * 4 + "Duration of Lease: " + str(leased_period) + "\n"
        invoice_text += "\t" * 4 + "Actual Duration Period: " + str(actual_lease_period) + "\n"
        fine = operations.calculate_fine(land['price'], land['anna'], extra_months)
        invoice_text += "\t" * 4 + "Your fine for delayed return is: Rs " + str(abs(fine)) + "\n"
    elif actual_lease_period > leased_period:
        invoice_text += "\t" * 4 + "Duration of Lease: " + str(leased_period) + "\n"
        invoice_text += "\t" * 4 + "Actual Duration Period: " + str(actual_lease_period) + "\n"
        refund = operations.calculate_remaining_money(land['price'], land['anna'], remaining_months)
        invoice_text += "\t" * 4 + "Your refund is: Rs " + str(abs(refund)) + "\n"

    print(invoice_text)  # Print invoice to terminal

    # Update table in terminal
    land['status'] = "Available"
    update_file_after_return(land['kitta_number'], "Available")

    # Write the invoice to a file
    if filename:
        with open(filename, 'a') as file:
            file.write(invoice_text + "\n\n")
    else:
        print("No filename provided.")

    return invoice_text  # Return the invoice text for further processing if needed

def update_file_after_rent(kitta_number, new_status, filename='table.txt'):
    try:
        # Read existing data
        lines = []
        with open(filename, 'r') as file:
            for line in file:
                data = line.split('|')
                if int(data[0]) == kitta_number:
                    # Ensure the length of the new status is the same as the previous one
                    data[5] = new_status.ljust(len(data[5]))
                    line = '|'.join(data)
                lines.append(line)

        # Write updated data back to file
        with open(filename, 'w') as file:
            file.writelines(lines)
    except FileNotFoundError:
        print("Error: Data file not found.")

def update_file_after_return(kitta_number, new_status, filename='table.txt'):
    try:
        # Read existing data
        lines = []
        with open(filename, 'r') as file:
            for line in file:
                data = line.split('|')
                if int(data[0]) == kitta_number:
                    # Ensure the length of the new status is the same as the previous one
                    data[5] = new_status.ljust(len(data[5]))
                    line = '|'.join(data)
                lines.append(line)

        # Write updated data back to file
        with open(filename, 'w') as file:
            file.writelines(lines)
    except FileNotFoundError:
        print("Error: Data file not found.")


