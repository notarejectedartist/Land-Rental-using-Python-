import datetime

def rent_total_cost(price_per_aana, anna, lease_period):
    return price_per_aana * anna * lease_period

def generate_code():
    m1 = str(datetime.datetime.now().minute)
    m2 = str(datetime.datetime.now().second)
    m3 = str(datetime.datetime.now().microsecond)
    return m1 + m2 + m3

def calculate_fine(price, anna, extra_months):
    return 0.1 * price * anna * extra_months

def calculate_remaining_money(price, anna, remaining_months):
    return price * anna * remaining_months
